import pymongo

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    def __init__(self, username = None, password = None):
        self.client = MongoClient('mongodb://%s:%s@localhost:35896/AAC' % ("aacuser", "cameron12"))
        self.database = self.client['AAC']
        
        
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)
            if insert != 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
            
    def read(self, criteria=None):
        if criteria:
            data = self.database.animals.find(criteria, {"_id": False})
        else:
            data = self.database.animals.find({}, {"_id": False})
            
        return data
    
    def update(self, criteria=None, old_value=None, value=None):
        if criteria:
            query_update = {criteria: old_value}
            new_value = {"$set":{criteria:value}}
            update_data = self.database.animals.update({query_update, new_value})
            print(update_data, "data is inserted")
        else:
            print("data was not inserted")
        
    def delete(self, name):
        query_delete = self.database.animals.delete({"breed":name})
        return query_delete
        print("data has been removed")




